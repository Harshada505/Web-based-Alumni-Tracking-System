<?php 

$conn= new mysqli('localhost','root','','alumni_db1')or die("Could not connect to mysql".mysqli_error($con));
?>
